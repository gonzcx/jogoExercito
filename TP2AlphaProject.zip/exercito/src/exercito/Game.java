package exercito;

import java.util.Scanner;


/**
 * This class is the main class of the "World of Zuul" application. "World of
 * Zuul" is a very simple, text based adventure game. Users can walk around some
 * scenery. That's all. It should really be extended to make it more
 * interesting!
 * 
 * To play this game, create an instance of this class and call the "play"
 * method.
 * 
 * This main class creates and initialises all the others: it creates all rooms,
 * creates the parser and starts the game. It also evaluates and executes the
 * commands that the parser returns.
 * 
 * @author Michael Kolling and David J. Barnes
 * @version 2008.03.30
 */

public class Game {
	private Parser parser;
	private Room currentRoom;
	Raffle raffle = new Raffle();
	Scanner teclado = new Scanner(System.in);	
	private final int[] jaVisitouEsseObjeto =  new int[20]; //esse vetor vai conferir se o usuário já visitou anteriormente o objeto que ele está
	Militar militar = new Militar();
        General general = new General();
        Tenente tenente = new Tenente();
        Soldado soldado = new Soldado();
         
        /**
	 * Create the game and initialise its internal map.
	 */
	public Game() {
		createRooms();
		parser = new Parser();
	}

	/**
	 * Create all the rooms and link their exits together.
	 */
	private void createRooms() {
		Room outside, dormitorio, refeitorio, salaOperacoes, academia, salaReuniao, banheiro, campoTreinamento;

		// create the rooms
		outside = new Room("na parte de fora do alojamento (outside)");
		dormitorio = new Room("no dormitório dos soldados");
		refeitorio = new Room("no refeitório");
		salaOperacoes = new Room("na sala de operações");
		academia = new Room("na academia");
		salaReuniao = new Room("na sala de reunião dos tenentes");
		banheiro = new Room("no banheiro");
		campoTreinamento = new Room("no campo de treinamento dos soldados");

		// mostrando para onde você irá utilizando tal comando
		outside.setExit("east", salaOperacoes);
		outside.setExit("north", refeitorio);
		outside.setExit("west", academia);

		refeitorio.setExit("south", outside);
		refeitorio.setExit("north", salaReuniao);
		refeitorio.setExit("west", campoTreinamento);

		academia.setExit("east", outside);
		academia.setExit("north", campoTreinamento);

		salaOperacoes.setExit("west", outside);

		campoTreinamento.setExit("south", academia);
		campoTreinamento.setExit("north", banheiro);
		campoTreinamento.setExit("east", refeitorio);

		banheiro.setExit("east", salaReuniao);
		banheiro.setExit("south", campoTreinamento);

		salaReuniao.setExit("north", dormitorio);
		salaReuniao.setExit("south", refeitorio);
		salaReuniao.setExit("west", banheiro);

		dormitorio.setExit("south", salaReuniao);

		currentRoom = outside; // Começando o jogo em outside
	}

	/**
	 * Main play routine. Loops until end of play.
	 */
	public void play() {
		printWelcome();

		// Enter the main command loop. Here we repeatedly read commands and
		// execute them until the game is over.

		boolean finished = false;
		while (!finished) {
			Command command = parser.getCommand();
			finished = processCommand(command);
		}
		System.out.println("Vai nos abandonar mesmo " +militar.getPatente()+ "? Não esperávamos isso de você.");
                System.exit(0);
	}

	/**
	 * Print out the opening message for the player.
	 */
	private void printWelcome() {
 
		// vamos sortear os distrativos aqui para que esse sorteio só ocorra uma vez
		raffle.sortearDistrativos();
                
                
           
		System.out.println("Bem vindo ao quartel. Informe o seu nome:");
		String user = teclado.next();
                System.out.println("Qual seu sexo?(m ou f)");
                                   
                                    int x = 0;
                                   
                                   while(x!=1){     
                                    militar.setSexo(teclado.next().charAt(0));
                                    char resposta = Character.toLowerCase(militar.getSexo());
                                    militar.setSexo(resposta);
                                    if(resposta == 'm' || resposta == 'f'){
                                        x++;
                                    }    
                                    else{
                                        System.out.println("Digite um sexo válido.");
                                    }
                                   }
                System.out.println("");
		System.out.println( user + ", te chamamos com urgência para o quartel"
				+ "\nporque fomos avisados pelos guerrilheiros que uma bomba foi dispejada"
				+ "\nno nosso alojamento, mas não fazemos ideia de onde ela possa estar "
				+ "\nescondida. Você é o único que pode nos ajudar. Confiamos em você."
				+ "\nPS: A cada objeto que você olhar, você perderá tempo.\nE tome cuidado"
				+ " com os distrativos que estão espalhados aleatoriamente pelo mapa."
				+ "\nDigite \"help\" se precisar de alguma ajuda."
                                + "\nInforme sua Patente(lembrando que isso afetará a dificuldade do jogo)\nGeneral: 20 minutos(Fácil)"
                                + "\nTenente: 15 minutos(Médio)\nSoldado: 10 minutos(Difícil)\nCivil : IMPOSSÍVEL");
                                  String tec = " ";                             
                                  int y = 0;
                                  while(y!=1){
                                  tec = teclado.next().toLowerCase(); 
                                  if(tec.equals("civil")){
                                      System.out.println("Espere um pouco, você é um civil? O que está fazendo aqui? Quem trouxe esse cara?"
                                              + "Já para fora, chamem um militar!!");
                                  }
                                  else{ militar.setPatente(tec);
                                  }
                                if(militar.getPatente().equals("soldado")){
                                    y++;
                                    raffle.setTempo(10);
                                    soldado.setSexo(militar.getSexo());
                                    soldado.fardas(soldado.getSexo());
                
                                }
                                else if(militar.getPatente().equals("tenente")){
                                    y++;
                                    raffle.setTempo(15);
                                    tenente.setSexo(militar.getSexo());
                                    tenente.fardas(tenente.getSexo());
                                }
                                else if(militar.getPatente().equals("general")){
                                    y++;
                                    raffle.setTempo(20);
                                    general.setSexo(militar.getSexo());
                                    general.fardas(general.getSexo());
                                }
                               
                                else{
                                    System.out.println("Digite uma opção válida.");
                                    
                                    
                                } 
                                  }
                                
                                
                
                
				
		// esse system abaixo informa aonde você começa o jogo
		System.out.println(currentRoom.getLongDescription());

	}

	/**
	 * Given a command, process (that is: execute) the command.
	 * 
	 * @param command The command to be processed.
	 * @return true If the command ends the game, false otherwise.
	 */
	private boolean processCommand(Command command) {
		boolean wantToQuit = false;

		// esse if ocorrerá caso o usuário digite algum comando inválido.
		if (command.isUnknown()) {
			System.out.println(militar.getPatente()+ ", não estou entendendo o que você deseja fazer.");
			return false;
		}

		String commandWord = command.getCommandWord();
		// método que mostra a lista de comandos existentes
		if (commandWord.equals("help")) {
			printHelp();
		}
		// método que diz que você deseja se locomover
		else if (commandWord.equals("go")) {
			goRoom(command);
		}
		// método que diz em qual sala você está
		else if (commandWord.equals("look")) {
			look();
		}
		// método que termina o jogo
		else if (commandWord.equals("quit")) {
			wantToQuit = quit(command);
		}
		// método que mostra o mapa do jogo
		else if (commandWord.equals("map")) {
			map(command);
		}
		// else command not recognised.
		return wantToQuit;
	}

	// implementations of user commands:

	private void look() {
		// esse método pega a sala que você está no momento e dá o nome dela
		System.out.println(currentRoom.getLongDescription());
	}

	// Esse método diz os comandos do jogo que existem
	private void printHelp() {
		System.out.println(militar.getPatente()+", você deve desarmar uma bomba que está escondida.");
		System.out.println("Os comandos que você pode utilizar são:");
		System.out.println(parser.listCommands());
	}

	/**
	 * Try to go to one direction. If there is an exit, enter the new room,
	 * otherwise print an error message.
	 */
	private void goRoom(Command command) {
		if (!command.hasSecondWord()) {
			// if there is no second word, we don't know where to go...
			System.out.println("Vai pra onde?");
			return;
		}

		String direction = command.getSecondWord();

		// Try to leave current room.
		Room nextRoom = currentRoom.getExit(direction);

		if (nextRoom == null) {
			System.out.println("Você está tentando ir para um local inválido!");
		} else {
			// entrou em uma nova sala
			currentRoom = nextRoom;
			System.out.println(currentRoom.getLongDescription());
			getObjetosCurrentRoom();
		}
	}

	private void map(Command command) {
		command.getMap();

	}

	/**
	 * "Quit" was entered. Check the rest of the command to see whether we really
	 * quit the game.
	 * 
	 * @return true, if this command quits the game, false otherwise.
	 */
	private boolean quit(Command command) {
		if (command.hasSecondWord()) {
			System.out.println("O que você quis dizer?");
			return false;
		} else {
			return true; // signal that we want to quit
		}
	}

	// método que vai percorrer dentro de cada sala
	private void getObjetosCurrentRoom() {
		char procurarBombaAqui;
		boolean querContinuarAqui = true;
		while (querContinuarAqui == true) {
			if (currentRoom.getShortDescription().contains("outside")) {
				System.out.println("Escolha um destino para ir, aqui no outside não tem o que procurar.");
				querContinuarAqui = false;
			} else {				 
					 System.out.println("Você quer procurar a bomba nessa sala? (S/N)");
						 procurarBombaAqui = teclado.next().charAt(0);				 
					 if(procurarBombaAqui == 'S') {
							System.out.println("Aonde você deseja procurar pela bomba?");
							getOpcoes(); // cada sala terá suas opções de onde a bomba possa estar dentro dela
							int resposta = teclado.nextInt();
							getSwitch(resposta);
							System.out.println("Quer continuar nessa sala? (S/N)");
							char continuar = teclado.next().charAt(0);
							if (continuar == 'N') {
								querContinuarAqui = false;
							}else if (continuar == 'S') {								
								procurarBombaAqui = 'S';
							}else {
								System.out.println("Você digitou um comando inválido.");
							}
						}else {
							System.out.println("Digite o próximo comando.");
						break; //se o usuário não quiser procurar a bomba nessa sala, o ciclo encerrará 
						 
				 }
				
				
				
			}
		}

	}

	private void getOpcoes() {
		if (currentRoom.getShortDescription().contains("academia")) {
			System.out.println("1)Atrás do peso de 15 kg;\n2)Embaixo do tapete;\n3)Dentro da mochila;");
		} else if (currentRoom.getShortDescription().contains("operações")) {
			System.out.println(
					"1)Embaixo da mesa cirúrgica;\n2)Dentro do armário;\n3)Dentro da farda velha do soldado ferido;");
		} else if (currentRoom.getShortDescription().contains("refeitório")) {
			System.out.println("1)Em cima da mesa;\n2)Dentro do fogão;\n3)Geladeira;");
		} else if (currentRoom.getShortDescription().contains("dormitório")) {
			System.out.println("1)Cama 1;\n2)Cama 2;\n3)Cama 3;");
		} else if (currentRoom.getShortDescription().contains("banheiro")) {
			System.out.println("1)Dentro da privada;\n2)Debaixo da pia;\n3)Atrás do espelho;");
		} else if (currentRoom.getShortDescription().contains("treinamento")) {
			System.out.println("1)Atrás do alvo de tiro;\n2)Do lado dos fuzis de assalto;");
		} else if (currentRoom.getShortDescription().contains("reunião")) {
			System.out.println("1)Em cima da cadeira;\n2)Atrás da porta;\n3)Dentro da almofada do sofá;");
		}

	}

	private void getSwitch(int resp) {
		  int i;
		  
		  if (currentRoom.getShortDescription().contains("academia")) {
					switch(resp) {
					case 1: //objeto 0: peso15kg
						i=0;//número do objeto
						raffle.ganhou(i); //se no objeto que você estiver procurando estiver a bomba, você ganha o jogo
						raffle.distrativos(i); //conferindo se nesse objeto tem algum distrativo
						VisitouEsseObjeto(i);//vai analisar se o usuário já visitou essa sala antes
						break;
					case 2://objeto 1: tapete
						i=1;
						raffle.ganhou(i);
						raffle.distrativos(i);
						VisitouEsseObjeto(i);
						break;
					case 3://objeto 2: mochila 
						i=2;
						raffle.ganhou(i);
						raffle.distrativos(i);
						VisitouEsseObjeto(i);
						break;
						default: System.out.println("Você digitou um número inválido.");
					}	
				
			  
			} else if (currentRoom.getShortDescription().contains("operações")) {
				switch(resp) {
				case 1:
					i=3;//objeto 3: mesa
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                        
					break;
				case 2:
					i=4;//objeto 4: armário
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                        
					break;
				case 3:
					i=5;//objeto 5: fardaVelha
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                        
					break;
					default: System.out.println("Você digitou um número inválido.");
				}
			} else if (currentRoom.getShortDescription().contains("refeitório")) {
				switch(resp) {
				case 1:
					i=6;//objeto 6: mesa
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                        
					break;
				case 2:
					i=7;//objeto 7: fogão
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                        
					break;
				case 3:
					i=8;//objeto 8: geladeira
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                        
					break;
					default: System.out.println("Você digitou um número inválido.");
				}
			} else if (currentRoom.getShortDescription().contains("dormitório")) {
				switch(resp) {
				case 1:
					i=9;//objeto 9: cama1
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                       
					break;
				case 2:
					i=10;//objeto 10: cama2
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                        
					break;
				case 3:
					i=11;//objeto 11: cama3
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                       
					break;
					default: System.out.println("Você digitou um número inválido.");
				}
			} else if (currentRoom.getShortDescription().contains("banheiro")) {
				switch(resp) {
				case 1:
					i=12;//objeto 12: privada
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                        
                                        
					break;
				case 2:
					i=13;//objeto 13: pia
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                       
					break;
				case 3:
					i=14;//objeto 14: espelho
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                       
					break;
					default: System.out.println("Você digitou um número inválido.");
				}
			} else if (currentRoom.getShortDescription().contains("treinamento")) {
				switch(resp) {
				case 1:
					i=15;//objeto 15: alvo
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                        
					break;
				case 2:
					i=16;//objeto 16: fuzisDeAssalto
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                       
					break;
					default: System.out.println("Você digitou um número inválido.");
				}
			}else if(currentRoom.getShortDescription().contains("reunião")) {				
				switch(resp) {
				case 1:
					i=17;//objeto 17: cadeira
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);

					break;
				case 2:
					i=18;//objeto 18: porta
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                        
					break;
					
				case 3:
					i=19;//objeto 19: sofá
					raffle.ganhou(i);
					raffle.distrativos(i);
					VisitouEsseObjeto(i);
                                        
					break;
					default: System.out.println("Você digitou um número inválido.");
				}
		    }	
			
		}
	
	private void VisitouEsseObjeto(int k) {
		if(jaVisitouEsseObjeto[k] >= 1) {
			System.out.println("Você já visitou esse objeto dessa sala "+jaVisitouEsseObjeto[k]+" vez(es)."
					+ " Você vai perder mais esse 1 minuto porque se esqueceu que tinha passado por aqui.");
			jaVisitouEsseObjeto[k]++;
		}else {
			jaVisitouEsseObjeto[k]++;
		}
	}
	


	

}
