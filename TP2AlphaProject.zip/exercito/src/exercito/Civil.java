/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercito;

/**
 *
 * @author Joao
 */
public class Civil extends Pessoa {
    public Civil(){
        
    }

    @Override
    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    @Override
    public char getSexo() {
        return sexo;
    }
    
}
