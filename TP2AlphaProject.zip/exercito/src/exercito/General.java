/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercito;

/**
 *
 * @author Joao
 */
public class General extends Militar implements Reviver {
    GUI_Gen_Masc genmasc = new GUI_Gen_Masc();
    GUI_Gen_Fem genfem = new GUI_Gen_Fem();
    public General(){
    
}
    @Override
    public void fardas(char sexo){
        if(sexo == 'm'){
        genmasc.setVisible(true);
        }
        else if(sexo == 'f'){
        genfem.setVisible(true);
        }
    }

    @Override
    public int diaDeSorte() {
        System.out.println("General, acorde! você dormiu no meio da missão, porque está assustado? Teve pesadelos? por sorte acordamos você a "
                + "tempo"
                + " você ainda tem 20 minutos");  
        return 20;
    }

    
} 
