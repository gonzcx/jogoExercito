/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercito;

/**
 *
 * @author Joao
 */
public class Militar extends Pessoa {
    protected static String patente;
    protected int uniforme;
  
    
    public Militar(){
        uniforme = 0;
    
        
    }
    @Override
    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }
    public void setUniforme(int uniforme) {
        this.uniforme = uniforme;
    }
    
    @Override
    public char getSexo() {
        return sexo;
    }

    public static String getPatente() {
        return patente;
    }
    
    public int getUniforme() {
        return uniforme;
    }
     public void fardas(char sexo){
         
     }
     

         
    

}
