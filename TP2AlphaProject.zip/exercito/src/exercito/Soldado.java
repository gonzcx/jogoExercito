/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercito;

/**
 *
 * @author Joao
 */
public class Soldado extends Militar {
    GUI_Sold_masc soldmasc = new GUI_Sold_masc();
    GUI_Sold_Fem soldfem = new GUI_Sold_Fem();
    public Soldado(){
        
    }
    
    @Override
    public void fardas(char sexo){
        if(sexo == 'm'){
            soldmasc.setVisible(true);
        }
        else if(sexo == 'f'){
            soldfem.setVisible(true);
        }
    }
    
}
