package exercito;

import java.util.Random;

public class Raffle {
	Random random;
	private final int bomba; // a bomba vai ser sorteada e só ficará em um único lugar, por isso recebe o "final"
	private int tempo;
        Militar militar = new Militar();
        General general = new General();
        Tenente tenente = new Tenente();
        Soldado soldado = new Soldado();
        int contadorReviver = 0;

    public int getTempo() {
        return tempo;
    }

    public void setTempo(int tempo) {
        this.tempo = tempo;
    }
	private final int[] distrativos = new int[7]; //distrativos que vão tornar o jogo mais difícil 

    
	public Raffle() {
		tempo = 0;// tempo que você terá para achar a bomba;
		random = new Random();
		bomba = random.nextInt(20); // a bomba vai variar de 0 a 19 (números dos objetos existentes) e vai ser sorteada logo no início do jogo
	}
	
	protected void distrativos(int k) {
		/*distrativos[0] = Videogame 
		 *distrativos[1] = Chocolate 
		 *distrativos[2] = Alfinete
		 *distrativos[3] = Revista playboy 
		 *distrativos[4] = Cigarro
		 *distrativos[5] = MP3
		 *distrativos[6] = Garrafa de vodka  
		 */
		int contador=0;
		//esse ciclo contará quantos distratores tem no mesmo lugar
		for(int i=0; i<distrativos.length; ++i) {		
			if(k == distrativos[i]) {
				contador++;
			}
			}
		
		if(contador == 1) {
			for(int i=0; i<distrativos.length; ++i) {		
				if(k == distrativos[i]) {				
					/*distrativos[0] = Videogame
					 *distrativos[1] = Chocolate
					 *distrativos[2] = Alfinete
					 *distrativos[3] = Revista playboy
					 *distrativos[4] = Cigarro
					 *distrativos[5] = MP3
					 *distrativos[6] = Garrafa de vodka 
					 */
					
						if(i==0) {
                                                        
                                                        
							System.out.println("BILHETE DO AZAR: Você encontrou um videogame. Você ganhou"
									+ " a partida no Mortal Kombat mas perdeu 3 minutos jogando.");
							tempo -= 3;

						}else if(i==1) {
							System.out.println("BILHETE DO AZAR: Você encontrou um chocolate. Como era um"
									+ " suflair você gastou 3 minutos o saboreando.");
							tempo -= 3;

						}else if(i==2) {
							System.out.println("BILHETE DO AZAR: Você encontrou um alfinete. Você machucou seu dedo"
									+ "e ficou 3 minutos tentando parar o sangue.");
							tempo -= 3;

						}else if(i==3) {
							System.out.println("BILHETE DO AZAR: Você encontrou uma revista playboy. Você gastou 3 minutos"
									+ " fazendo coisas que não devem ser ditas.");
							tempo -= 3;

						}else if(i==4) {
							System.out.println("BILHETE DO AZAR: Você encontrou um cigarro de origem desconhecida. Você"
									+ " ficou 3 minutos sobre o uso de drogas ilícitas.");
							tempo -= 3;

						}else if(i==5) {
							System.out.println("BILHETE DO AZAR: Você encontrou um MP3. Você sem querer clicou no play"
									+ " e começou a tocar um sertanejo que te lembra sua ex. Você passou 3 minutos chorando.");
							tempo -= 3;
;
						}else if(i==6) {
							System.out.println("BILHETE DO AZAR: Você encontrou uma garrafa de vodka. Você decidiu tomar um gole"
									+ " para esquecer a situação do seu time na série B. Você perdeu 3 minutos bebendo.");
							tempo -= 3;
						
					}
					
				}
			}
		} else if(contador >=2) {
			for(int i=0; i<distrativos.length; ++i) {		
				if(k == distrativos[i]) {				
					/*distrativos[0] = Videogame
					 *distrativos[1] = Chocolate
					 *distrativos[2] = Alfinete
					 *distrativos[3] = Revista playboy
					 *distrativos[4] = Cigarro
					 *distrativos[5] = MP3
					 *distrativos[6] = Garrafa de vodka 
					 */
					
						if(i==0) {
							System.out.println("BILHETE DO AZAR: Você encontrou um videogame. Você ganhou"
									+ " a partida no Mortal Kombat mas perdeu 3 minutos jogando.");
							tempo -= 3;
							
						}else if(i==1) {
							System.out.println("BILHETE DO AZAR: Você encontrou um chocolate. Como era um"
									+ " suflair você gastou 3 minutos o saboreando.");
							tempo -= 3;
							
						}else if(i==2) {
							System.out.println("BILHETE DO AZAR: Você encontrou um alfinete. Você machucou seu dedo"
									+ "e ficou 3 minutos tentando parar o sangue.");
							tempo -= 3;
							
						}else if(i==3) {
							System.out.println("BILHETE DO AZAR: Você encontrou uma revista playboy. Você gastou 3 minutos"
									+ " fazendo coisas que não devem ser ditas.");
							tempo -= 3;
						
						}else if(i==4) {
							System.out.println("BILHETE DO AZAR: Você encontrou um cigarro de origem desconhecida. Você"
									+ " ficou 3 minutos sobre o uso de drogas ilícitas.");
							tempo -= 3;
							
						}else if(i==5) {
							System.out.println("BILHETE DO AZAR: Você encontrou um MP3. Você sem querer clicou no play"
									+ " e começou a tocar um sertanejo que te lembra sua ex. Você passou 3 minutos chorando.");
							tempo -= 3;
							
						}else if(i==6) {
							System.out.println("BILHETE DO AZAR: Você encontrou uma garrafa de vodka. Você decidiu tomar um gole"
									+ " para esquecer a situação do seu time na série B. Você perdeu 3 minutos bebendo.");
							tempo -= 3;
							
						
					}
					
				}
			}
			
			
		}
		if(tempo<=0) {
                    //caso o usuário seja um general ou um tenente, em sua primeira morte ele poderá reviver.  
                            if(contadorReviver == 0 && militar.getPatente().equals("general")){
                                tempo = general.diaDeSorte();
                             contadorReviver++;
                                
                            }
                            else if(contadorReviver == 0 && militar.getPatente().equals("tenente")){
                                tempo = tenente.diaDeSorte();
                            contadorReviver++;
                            }
                            else{
                                System.out.println("BOOM. O seu tempo esgotou, a bomba explodiu e você não conseguiu achá-la."
						+ " Todo o nosso batalhão está morto agora. Esperávamos mais de você.");
				System.exit(0);
                            }
				
			}else {
				System.out.println("Você ainda tem "+tempo+ " minutos.");
			}
		
		
	}
	//fazendo com que os distrativos não fiquem no mesmo lugar que a bomba
	protected int sortearDistrativos(){
            int j = 0;
		for(int i=0; i<distrativos.length; ++i) {
			distrativos[i] = random.nextInt(20); //o distrativo pode estar em qualquer objeto existente
			if(distrativos[i] == bomba) { //um distrativo não pode estar no mesmo lugar que a bomba
            while (distrativos[i] == bomba) {
            	distrativos[i] = random.nextInt(20);
            }
                            j = distrativos[i];

			}
		}
             return j;
	}
	
	
	//pegar o valor da bomba (caso queira testar o jogo)
	protected int getBomba() {
		return bomba;
	}
	
	
	

	// essa classe vai sortear a bomba e os distrativos que te farão perder tempo

	protected void ganhou(int j) {
		if (j == bomba) { // se no objeto tiver a bomba
			System.out.println("Parabéns, você achou a bomba e conseguiu desarmá-la."
					+ " Nós sempre acreditamos em você capitão, bom trabalho! Agora"
					+ " o nosso alojamento está seguro novamente.");
			System.exit(0);

		} else {
			int posicaoDistrativo = 99;
			//criando um ciclo pra percorrer o vetor de distrativos (se tiver um distrativo, ele vai perder 3 min, e não 3 min + 1 min)
			for(int i=0; i<distrativos.length;++i) {
				if(j == distrativos[i]) {
					//nada ocorre, afinal ele já perdeu os 3 minutos do bilhete
					posicaoDistrativo = j;
					
				}
			}
			// caso não tenha nenhum bilhete, ele perderá só 1 minuto
			if(posicaoDistrativo == j) {
				//nada ocorrerá, já que ele já perdeu 3 minutos do bilhete
			}else {
				//ele perderá 1 minuto apenas
				tempo--;
				System.out.println("A bomba não está aqui. Você acaba de perder 1 minuto.");
			}
			
			
			if(tempo<=0) {
				System.out.println("BOOM. O seu tempo esgotou, a bomba explodiu e você não conseguiu achá-la."
						+ " Todo o nosso batalhão está morto agora. Esperávamos mais de você.");
				System.exit(0);
			}
		
			
			
			
		}
		
		

	}

	
	//esse método você pode chamar no printWelcome() caso queira conferir aonde os distrativos estão
	protected int saberOndeEstaoDistrativos() {
		for(int i=0; i<distrativos.length; ++i) {
		    System.out.println(distrativos[i]);	
			}
                return distrativos[0];
		}
	
	
	

}
